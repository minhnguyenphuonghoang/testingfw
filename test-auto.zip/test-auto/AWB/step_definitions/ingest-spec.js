// Team_Example Login
module.exports = function () {

    // this.APMLogin = function () {
    this.When(/^I click to Instances icon$/, function (callback) {
        browser.ignoreSynchronization = true;
        homePage.instancesIcon().then(function () {
            callback();
        });
    });

    this.Then(/^I should see Instances page$/, function (callback) {
        browser.ignoreSynchronization = true;
        instancesPage.getPage().then(function (completed) {
            assert.isTrue(completed, 'Not In Search Page');
            var EC = protractor.ExpectedConditions;
            TestHelperPO.isElementNotPresent(element(by.css('.spinner.style-scope.px-spinner'))).then(function () {
                callback()
            })
        });
    });

    this.When(/^I click Create Asset Instances button$/, function (callback) {
        browser.ignoreSynchronization = true;
        instancesPage.clickCreateButton().then(function () {
            callback();
        });
    });

    this.Then(/^I should see Instance Create page$/, function (callback) {
        browser.ignoreSynchronization = true;
        instancesPage.getCreatePage().then(function (completed) {
            assert.isTrue(completed, 'Not In Search Page');
            var EC = protractor.ExpectedConditions;
            var el = element(by.xpath('//div[@style="display: none;" and contains(@class,"overlay-loading style-scope instance-view")]'));
            browser.wait(EC.visibilityOf(el), 10000);
            callback();
        });

    });

    this.When(/^I click to List Of Templates$/, function (callback) {
        browser.ignoreSynchronization = true;
        instancesPage.clickTemplateList().then(function () {
            callback();
        });
    });

    this.When(/^I choose a template(.*)$/, function (templateName, callback) {
        browser.ignoreSynchronization = true;
        templateName = browser.params.ingest_data.template_name;
        instancesPage.chooseTemplate(templateName).then(function () {
            callback();
        });
    });

    this.When(/^I put all instances for template$/, function (callback) {
        browser.ignoreSynchronization = true;
        element(by.xpath('//div[@id="cell_00"]')).click().then(function () {
            element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data1).then(function () {
                element(by.xpath('//div[@id="cell_01"]')).click().then(function () {
                    element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data2).then(function () {
                        element(by.xpath('//div[@id="cell_02"]')).click().then(function () {
                            element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data3).then(function () {
                                element(by.xpath('//div[@id="cell_03"]')).click().then(function () {
                                    element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data4).then(function () {
                                        element(by.xpath('//div[@id="cell_04"]')).click().then(function () {
                                            element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data5).then(function () {
                                                element(by.xpath('//div[@id="cell_05"]')).click().then(function () {
                                                    element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data6).then(function () {
                                                        element(by.xpath('//div[@id="cell_06"]')).click().then(function () {
                                                            element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data7).then(function () {
                                                                element(by.xpath('//div[@id="cell_07"]')).click().then(function () {
                                                                    element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data8).then(function () {
                                                                        element(by.xpath('//div[@id="cell_08"]')).click().then(function () {
                                                                            element(by.xpath('//*[@id="editor_text"]')).sendKeys(browser.params.ingest_data.data9).then(function () {
                                                                                callback();
                                                                            });
                                                                        });
                                                                    });
                                                                });
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    this.When(/^I click to Save Instances button$/, function (callback) {
        browser.ignoreSynchronization = true;
        instancesPage.clickSaveInstancesButton().then(function () {
            callback();
        });
    });

    this.Then(/^I should see Instances has been created msg$/, function (callback) {
        browser.ignoreSynchronization = true;
        instancesPage.getCreatedMSG().then(function (completed) {
            assert.isTrue(completed, 'Creating Template is failed');
            callback();
        });

    });



};









