// Team_Example Login
module.exports = function () {

    // this.APMLogin = function () {
    this.When(/^I click to Register button$/, function (callback) {
        browser.ignoreSynchronization = true;
        tenantPage.clickRegister().then(function () {
            callback();

        });
    });

    this.Then(/^I should see Register Page$/, function (callback) {
        browser.ignoreSynchronization = true;
        registerTenantPage.getPage().then(function (completed) {            
            assert.isTrue(completed, 'Register Page is not shown');
            callback();
        });
    });

    this.When(/^I put first name(.*)$/, function (first_name, callback) {
        browser.ignoreSynchronization = true;
        first_name = browser.params.register_tenant.fname;
        registerTenantPage.enterFirstName(first_name).then(function () {
            callback();
        });

    });

    this.When(/^I put last name(.*)$/, function (last_name, callback) {
        browser.ignoreSynchronization = true;
        last_name = browser.params.register_tenant.lname;
        registerTenantPage.enterLastName(last_name).then(function () {
            callback();
        });

    });

    this.When(/^I put company(.*)$/, function (company, callback) {
        browser.ignoreSynchronization = true;
        last_name = browser.params.register_tenant.company;
        registerTenantPage.enterCompany(company).then(function () {
            callback();
        });

    });

    this.When(/^I put email(.*)$/, function (email, callback) {
        browser.ignoreSynchronization = true;
        email = browser.params.register_tenant.email;
        registerTenantPage.enterEmail(email).then(function () {
            callback();
        });
    });

    this.When(/^I put verify email(.*)$/, function (verifyemail, callback) {
        browser.ignoreSynchronization = true;
        verifyemail = browser.params.register_tenant.email;
        registerTenantPage.enterVerifyEmail(verifyemail).then(function () {
            callback();
        });
    });

    this.When(/^I put tenant name(.*)$/, function (tenantname, callback) {
        browser.ignoreSynchronization = true;
        tenantname = browser.params.register_tenant.tenant_name;
        registerTenantPage.enterTenantName(tenantname).then(function () {
            callback();
        });
    });

    this.When(/^I put asset url(.*)$/, function (asseturl, callback) {
        browser.ignoreSynchronization = true;
        asseturl = browser.params.register_tenant.asset_url;
        registerTenantPage.enterAsseturl(asseturl).then(function () {
            callback();
        });
    });

    this.When(/^I put asset id(.*)$/, function (assetid, callback) {
        browser.ignoreSynchronization = true;
        assetid = browser.params.register_tenant.asset_id;
        registerTenantPage.enterAssetID(assetid).then(function () {
            callback();
        });
    });

    this.When(/^I put uaa url(.*)$/, function (uaa_instance_url, callback) {
        browser.ignoreSynchronization = true;
        uaa_instance_url = browser.params.register_tenant.uaa_url;        
        registerTenantPage.enterUAAurl(uaa_instance_url).then(function () {
            callback();
        });
    });

    this.When(/^I click Grant Type list$/, function (callback) {
        browser.ignoreSynchronization = true;
        registerTenantPage.clickGrantType().then(function () {
            callback();
        });
    });

    this.When(/^I choose Client Credentials option$/, function (callback) {
        browser.ignoreSynchronization = true;
        registerTenantPage.chooseClientCredentialOption().then(function () {
            callback();
        });
    });

    this.When(/^I put uaa credentials(.*)$/, function (uaa_credential, callback) {
        browser.ignoreSynchronization = true;
        uaa_credential = browser.params.register_tenant.uaa_credential;
        registerTenantPage.enterUAAID(uaa_credential).then(function () {
            callback();
        });
    });

    this.When(/^I click Verify Button$/, function (callback) {
        browser.ignoreSynchronization = true;
        registerTenantPage.clickVerifyButton().then(function () {
            callback();
        });
    });

    this.Then(/^I should see Verified MSG$/, function (callback) {
        browser.ignoreSynchronization = true;        
            registerTenantPage.checkVerifyMsg().then(function (completed) {
                assert.isTrue(completed, 'Not Verify');
                callback();
            });        
    });

    this.When(/^I click Submit Button$/, function (callback) {
        browser.ignoreSynchronization = true;
        registerTenantPage.clickSubmitButton().then(function () {
            callback();
        });
    });

    this.Then(/^I should see Thank You page$/, function (callback) {
        browser.ignoreSynchronization = true;
        registerTenantPage.checkCreate().then(function (completed) {
            console.log(completed + "Duy");
            assert.isTrue(completed, 'The tenant has not been created');
            callback();
        });
    });

};
