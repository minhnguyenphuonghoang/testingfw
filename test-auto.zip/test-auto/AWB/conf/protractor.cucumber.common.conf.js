/**
 * Created by 212556710 on 5/9/16.
 */
exports.config = {

	// ---- While testing locally
	sauceUser: null,
	sauceKey: null,
	sauceSeleniumAddress: null,

	directConnect: false,
	firefoxPath: null,

	// ---------------------------------------------------------------------------
	// ----- What tests to run ---------------------------------------------------
	// ---------------------------------------------------------------------------

	// Spec patterns are relative to the location of this config.
	specs: [],

	// Patterns to exclude.
	exclude: [],

	// Organize spec files into suites. To run specific suite, --suite=<name of suite>
	suites: {
		// register_tenant: ['../Features/awb_Create_Tenant.feature'],
		login: ['../Features/awbLogin_success.feature', '../Features/awbLogin_fail.feature'],
		logout: ['../Features/awbLogout.feature'],
		ingest: ['../Features/awb_Inges_Instance.feature'],
		search: ['../Features/awbSearch.Query.feature','../Features/awbSearch.feature'],

	},

	maxSessions: 1,
	capabilities: {
		browserName: 'chrome',
		// proxy: {
		// 	proxyType: 'manual',
		// 	httpProxy: 'sjc1intproxy01.crd.ge.com:8080',
		// 	sslProxy: 'sjc1intproxy01.crd.ge.com:8080'
		// },
		count: 1,
		shardTestFiles: true,
		maxInstances: 1,
		'chromeOptions': {
			args: ['--no-sandbox', '--test-type=browser'],
			// Set download path and avoid prompting for download even though
			// this is already the default on Chrome but for completeness
			prefs: {
				'download': {
					'prompt_for_download': false,
					'directory_upgrade': true,
					'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
				}
			}
		}
	},

	params: {
		env: 'dev'
	},

	plugins: [{
		path: '../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',
	}],


	allScriptsTimeout: 10000,

	// How long to wait for a page to load.
	getPageTimeout: 10000,

	// Before launching the application
	beforeLaunch: function () {
	},

	// Application is launched but before it starts executing
	onPrepare: function () {
		browser.ignoreSynchronization = true;
		// Create reports folder if it does not exist
		var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
		var mkdirp = require('mkdirp');
		var reportsPath = "./Reports/";
		screenShotPath = "./ScreenShot/";
		mkdirp(screenShotPath, function (err) {
			if (err) {
				console.error(err);
			} else {
			}
		});
		mkdirp(reportsPath, function (err) {
			if (err) {
				console.error(err);
			} else {
			}
		});

		browser.manage().deleteAllCookies();
		browser.manage().timeouts().pageLoadTimeout(5000);
		browser.manage().timeouts().implicitlyWait(1000);
		browser.driver.manage().window().setSize(1600, 1024);
		chai = require('chai');
		expect = chai.expect;
		path = require('path');
		Cucumber = require('cucumber');
		fs = require('fs');


		// Initializing page object variables
		registerTenantPage = require('../page/awb-tenant-register-page.js');
		loginPage = require('../page/awb-login-po.js');
		tenantPage = require('../page/awb-tenant-page.js');
		homePage = require('../page/awb-home-page.js');
		searchPage = require('../page/awb-search-page.js');
		instancesPage = require('../page/awb-instances-page.js');

		// Initializing necessary utils from ProUI-Utils module
		TestHelper = require('ProUI-Utils').TestHelper;
		TestHelperPO = require('ProUI-Utils').TestHelperPO;
		ElementManager = require('ProUI-Utils').ElementManager;
		Logger = require('ProUI-Utils').Logger;
		var dir = path.resolve(__dirname);
		// cem = new ElementManager('C:/GE_AUTO/Git/ProUI/ProUI-master/AWB/common-element-repo.json');
		cem = new ElementManager(dir + '/common-element-repo.json');
		TestHelper.setElementManager(cem);
		RestHelper = require('ProUI-Utils').RestHelper;

		//commonTestData = require('../TestData/common-test-data.json').data;
	},

	// A callback function called once tests are finished
	onComplete: function () {
		
	},


	// A callback function called once tests are cleaning up
	onCleanUp: function (exitCode) {

	},

	// A callback function after tests are launched
	afterLaunch: function () {

	},

	// Browser parameters for feature files.
	params: {
		login: {
			baseUrl: 'https://predix-asset-modeler-ui-aw-autotest.run.aws-usw02-pr.ice.predix.io/home/',
			"tenantname": "aw-autotest",
			"username": "johnsmith",
			"Iusername": "Ajohnsmith",
			"password": "awb",
			"query": "all in School",
			"search": "School?filter=uri=/School/School_1",
		},
		ingest_data: {
			template_name: ' Daniel_Associated',
			data1: 'School_1',
			data2: 'GE_School',
			data3: 'S1',
			data4: 'School_1',
			data5: 'Class001',
			data6: 'CS',
			data7: 'Class001',
			data8: 'Student010',
			data9: 'Daniel',
			data10: '25',
			data11: 'Student010'

		},
		register_tenant: {
			fname: ' Daniel',
			lname: 'Nguyen',
			company: 'FPT',
			email: 'daniel.nguyen@GE.com',
			tenant_name: 'autotest1',
			asset_url: 'https://predix-asset.run.aws-usw02-pr.ice.predix.io',
			asset_id: 'ecf585cc-d338-4ddb-9cf9-9d02547a382f',
			uaa_url: 'https://a5affd77-0abd-4eb0-88b6-e4d50baed86a.predix-uaa.run.aws-usw02-pr.ice.predix.io',
			grant_type: '',
			uaa_credential: 'YXdiOmF3Yg=='
		},


	},

	resultJsonOutputFile: null,

	// If true, protractor will restart the browser between each test.
	// CAUTION: This will cause your tests to slow down drastically.
	restartBrowserBetweenTests: false,

	// Custom framework in this case cucumber
	framework: 'custom',
	frameworkPath: require.resolve('protractor-cucumber-framework'),
	cucumberOpts: {

		// define your step definitions in this file
		require: [
			'../step_definitions/login-spec.js',
			'../step_definitions/search-spec.js',
			'../step_definitions/register-tenant-spec.js',
			'../step_definitions/env.js',
			'../step_definitions/login-spec.js',
			'../step_definitions/ingest-spec.js',
			'../../Test_Modules/Assets/step_definitions/*',
			'../../node_modules/proui-utils/Compressed_Utils/Reporter.js',			
			'../../Test_Modules/Highchart/step_definitions/*',
			'../../Test_Modules/RestAPIExample/step_definitions/rest-example-step-def-highchart.js',
			'../../Test_Modules/RestAPIExample/step_definitions/rest-example-step-def.js',
			'../../Test_Modules/SinglePage/Step_Definitions/singlepage-step-def.js'
		],

		//format: 'pretty'
	}
};
