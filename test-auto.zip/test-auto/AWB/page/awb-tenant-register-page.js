/**
 * Copyright (c) 2013 - 2015 GE Global Research. All rights reserved.
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

(function () {
    'use strict';


    var currentPage = 'registerTenantPage';


    var tenantRegisterPage = function () {

        return {
            getPage: function () {
                return TestHelper.isElementPresent(currentPage, 'firstname');
            },

            enterFirstName: function (fname) {
                return cem.findElement(currentPage, 'firstname').sendKeys(fname);
            },

            enterLastName: function (lname) {
                return cem.findElement(currentPage, 'lastname').sendKeys(lname);
            },

            enterCompany: function (company) {
                return cem.findElement(currentPage, 'company').sendKeys(company);
            },

            enterEmail: function (email) {
                return cem.findElement(currentPage, 'email').sendKeys(email);
            },

            enterVerifyEmail: function (verifyemail) {
                return cem.findElement(currentPage, 'verifyemail').sendKeys(verifyemail);
            },

            enterTenantName: function (tenantname) {
                return cem.findElement(currentPage, 'tenantname').sendKeys(tenantname);
            },

            enterAsseturl: function (asseturl) {
                return cem.findElement(currentPage, 'asseturl').sendKeys(asseturl);
            },

            enterAssetID: function (assetid) {
                return cem.findElement(currentPage, 'assetid').sendKeys(assetid);
            },

            enterUAAurl: function (uaaurl) {
                console.log(uaaurl);
                return cem.findElement(currentPage, 'uaaurl').sendKeys(uaaurl);
            },

            clickGrantType: function () {
                return cem.findElement(currentPage, 'granttype').click();
            },

            chooseClientCredentialOption: function () {
                return cem.findElement(currentPage, 'clientcredentials').click();
            },

            enterUAAID: function (uaaid) {
                return cem.findElement(currentPage, 'uaaid').sendKeys(uaaid);
            },

            clickSubmitButton: function () {
                return cem.findElement(currentPage, 'submitbutton').click();
            },

            clickVerifyButton: function () {
                return cem.findElement(currentPage, 'verifybutton').click();
            },


            clickUsername: function () {
                return cem.findElement(currentPage, 'userName').click();
            },

            clickLogOut: function () {
                return cem.findElement(currentPage, 'logoutButton').click();
            },

            searchIcon: function () {
                return cem.findElement(currentPage, 'searchIcon').click();
            },

            instancesIcon: function () {
                return cem.findElement(currentPage, 'instancesIcon').click();
            },

            checkVerifyMsg: function () {
                browser.sleep(1000);
                return TestHelperPO.isElementNotPresent(element(by.xpath('//button[contains(.,"Submit") and @disabled]')));
            },

            checkCreate: function () {
                return TestHelper.isElementPresent(currentPage, 'signinbutton');
            },
        }

    };

    module.exports = new tenantRegisterPage();

}());